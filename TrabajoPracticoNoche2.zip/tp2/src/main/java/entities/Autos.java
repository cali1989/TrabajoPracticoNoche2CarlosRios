package entities;



import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Autos extends Vehiculos{
    
    private int puertas;

    public Autos(String marca, String modelo, Double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    
    }

    
    

    






