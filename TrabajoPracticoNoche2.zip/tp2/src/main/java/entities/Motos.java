package entities;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Motos extends Vehiculos {
    
    private String cilindrida;

    public Motos(String marca, String modelo, Double precio, String cilindrida) {
        super(marca, modelo, precio);
        this.cilindrida = cilindrida;
    }

    

    
}
