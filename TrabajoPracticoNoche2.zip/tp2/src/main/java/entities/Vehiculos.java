package entities;




import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode

public abstract class Vehiculos implements Comparable<Vehiculos>{
    

   private String marca;
   private String modelo;
   private Double precio;
   


    public Vehiculos(String marca, String modelo, Double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    
    
    
        }

        @Override
        public int compareTo(Vehiculos otros) {
            String thisVehiculos=this.getMarca()+","
            +this.getModelo()
            +","+this.getPrecio();
            String otrosVehiculos=otros.getMarca()+","+
            otros.getModelo()+","+otros.getPrecio();
            return thisVehiculos.compareTo(otrosVehiculos);

            

    
}
}



    

    



    


    



    

    



    

