package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import entities.Autos;
import entities.Motos;
import entities.Vehiculos;

public class TestCollections {
    
    public static void main(String[] args) {
        List<Vehiculos> vehiculos = cargarVehiculos();

        vehiculos.forEach(System.out::println);

        System.out.println("=============================");
        System.out.println("Vehículo más caro: " + vehiculoMasCaro(vehiculos).getMarca());
        System.out.println("Vehículo más barato: " + vehiculoMasBarato(vehiculos).getMarca());
        System.out.println("Vehículo que contiene en el modelo la letra 'Y': " + vehiculoConLetraY(vehiculos).getMarca());
        System.out.println("=============================");
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos = ordenarPorPrecio(vehiculos);
        vehiculos.forEach(v -> System.out.println(v.getMarca()));
        System.out.println("=============================");
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        Collections.sort(vehiculos);
        vehiculos.forEach(System.out::println);
    }

    public static List<Vehiculos> cargarVehiculos() {
        List<Vehiculos> vehiculos = new ArrayList<>();
        vehiculos.add(new Autos("Peugeot", "206", 200000.0, 4));
        vehiculos.add(new Motos("Honda", "Titan", 60000.0, "125c"));
        vehiculos.add(new Autos("Peugeot", "208", 250000.0, 5));
        vehiculos.add(new Motos("Yamaha", "YBR", 80500.50, "160c"));
        return vehiculos;
    }

    public static Vehiculos vehiculoMasCaro(List<Vehiculos> vehiculos) {
        return vehiculos.stream()
                .max((v1, v2) -> Double.compare(v1.getPrecio(), v2.getPrecio()))
                .orElse(null);
    }

    public static Vehiculos vehiculoMasBarato(List<Vehiculos> vehiculos) {
        return vehiculos.stream()
                .min((v1, v2) -> Double.compare(v1.getPrecio(), v2.getPrecio()))
                .orElse(null);
    }


    public static Vehiculos vehiculoConLetraY(List<Vehiculos> vehiculos) {
        for (Vehiculos vehiculo : vehiculos) {
            if (vehiculo.getMarca().toUpperCase().contains("Y")) {
                return vehiculo;
            }
        }
        return null;
    }

    public static List<Vehiculos> ordenarPorPrecio(List<Vehiculos> vehiculos) {
        vehiculos.sort((v1, v2) -> Double.compare(v2.getPrecio(), v1.getPrecio()));
        return vehiculos;
    }
}


